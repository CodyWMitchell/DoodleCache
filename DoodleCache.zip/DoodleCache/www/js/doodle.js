class Line {
    constructor(points=[]) {
        this.points=points;
    }

    draw() {
        for (var i=0; i<this.points.length-1; i++) {
            line(this.points[i][0],this.points[i][1],this.points[i+1][0],this.points[i+1][1]);
        }
    }
}

class Drawing {
    constructor(x,y,lineList=[]) {
        this.x=x;
        this.y=y;
        this.lines=lineList;
    }

    draw() {
        for (var i=0; i<this.lines.length; i++) {
            translate(x,y);
            this.lines[i].draw();
        }
    }
}
